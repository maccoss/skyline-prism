#!/usr/bin/env python3
"""Skyline External Tool launcher for PRISM.

This script is invoked by Skyline when the user runs the PRISM External Tool.
It:
1. Parses the report and metadata files from Skyline
2. Shows a configuration dialog for PRISM parameters
3. Runs the PRISM pipeline with user-selected settings
4. Launches the PRISM viewer to display results
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Note: yaml import moved to run_prism_pipeline to avoid import errors before installation

# Add tool root to sys.path to find bundled skyline_prism package
# The script is in Scripts/run_prism.py, so root is two levels up
tool_root = Path(__file__).parent.parent
if str(tool_root) not in sys.path:
    sys.path.insert(0, str(tool_root))


def ensure_dependencies() -> bool:
    """Check and install required Python dependencies."""
    required_packages = [
        "numpy",
        "pandas",
        "scipy",
        "scikit-learn",
        "pyarrow",
        "pyyaml",
        "duckdb",
        "PyQt6",
        "PyQt6-WebEngine",
        "matplotlib",
        "seaborn",
    ]

    import importlib.util
    import subprocess

    missing = []
    package_map = {
        "pyyaml": "yaml",
        "scikit-learn": "sklearn",
        "PyQt6-WebEngine": "PyQt6.QtWebEngineWidgets",
    }

    print("Checking dependencies...")
    for pkg in required_packages:
        module_name = package_map.get(pkg, pkg)
        # Handle submodules like PyQt6.QtWebEngineWidgets
        if "." in module_name:
            base, sub = module_name.split(".", 1)
            if importlib.util.find_spec(base) is None:
                missing.append(pkg)
                continue
            # Logic to check submodule is harder without importing, but usually base pkg install covers it.
            # For PyQt6-WebEngine, it's a separate pip package but namespace package.
            # We'll trust find_spec or just try to install if doubt.
            # Actually find_spec("PyQt6") might work but find_spec("PyQt6.QtWebEngineWidgets") requires imports?
            # Let's simple check: try import? No, might crash.
            # Use subprocess pip list? Slow.
            # Let's trust find_spec for now.
            pass
        else:
            if importlib.util.find_spec(module_name) is None:
                missing.append(pkg)

    if not missing:
        return True

    print(f"Installing missing dependencies: {', '.join(missing)}")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
        print("Dependencies installed successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Failed to install dependencies: {e}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"Error installing dependencies: {e}", file=sys.stderr)
        return False


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments from Skyline."""
    parser = argparse.ArgumentParser(description="Run PRISM analysis from Skyline External Tool")
    parser.add_argument(
        "--report",
        type=Path,
        required=True,
        help="Path to the Skyline-PRISM report CSV file",
    )
    parser.add_argument(
        "--metadata",
        type=Path,
        required=True,
        help="Path to the Replicates report CSV file (sample metadata)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Output directory for PRISM results",
    )
    return parser.parse_args()


def check_batch_column(metadata_path: Path) -> bool:
    """Check if the metadata file contains a 'Batch' column."""
    import pandas as pd

    try:
        # Read just the header to check columns
        df = pd.read_csv(metadata_path, nrows=0)
        columns_lower = [c.lower() for c in df.columns]
        return "batch" in columns_lower
    except Exception:
        return False


def show_config_dialog(metadata_path: Path) -> dict | None:
    """Show the PRISM configuration dialog and return settings.

    Args:
        metadata_path: Path to the metadata CSV file.

    Returns:
        Dictionary of configuration settings, or None if user cancelled.

    """
    # Check if batch column exists
    has_batch = check_batch_column(metadata_path)

    try:
        from PyQt6.QtWidgets import QApplication

        from skyline_prism.gui.config_dialog import PRISMConfigDialog

        _app = QApplication(sys.argv)
        dialog = PRISMConfigDialog(has_batch_column=has_batch)

        if dialog.exec():
            return dialog.get_config()
        else:
            return None
    except ImportError:
        # PyQt not available - use defaults
        print("PyQt6 not available, using default configuration", file=sys.stderr)
        return get_default_config(has_batch)


def get_default_config(has_batch: bool = True) -> dict:
    """Return default PRISM configuration."""
    return {
        "transition_rollup": {
            "enabled": True,
            "method": "adaptive",
            "min_transitions": 3,
            "learn_adaptive_weights": True,
        },
        "global_normalization": {
            "method": "rt_lowess",
        },
        "peptide_batch_correction": {
            "enabled": has_batch,
        },
        "parsimony": {
            "enabled": False,
            "shared_peptide_handling": "all_groups",
        },
        "protein_rollup": {
            "method": "median_polish",
            "min_peptides": 2,
        },
        "protein_normalization": {
            "method": "median",
        },
        "protein_batch_correction": {
            "enabled": has_batch,
        },
    }


def run_prism_pipeline(
    report_path: Path,
    metadata_path: Path,
    output_dir: Path,
    config: dict,
) -> bool:
    """Run the PRISM pipeline with the given configuration.

    Args:
        report_path: Path to the Skyline report CSV.
        metadata_path: Path to the metadata CSV.
        output_dir: Output directory for results.
        config: Configuration dictionary.

    Returns:
        True if pipeline completed successfully, False otherwise.

    """
    import subprocess
    import yaml  # Import locally after install

    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)

    # Write config to temporary file
    config_path = output_dir / "prism-config.yaml"
    with open(config_path, "w") as f:
        yaml.safe_dump(config, f, default_flow_style=False)

    # Build prism command
    cmd = [
        sys.executable,
        "-m",
        "skyline_prism.cli",
        "run",
        "-i",
        str(report_path),
        "-m",
        str(metadata_path),
        "-o",
        str(output_dir),
        "-c",
        str(config_path),
    ]

    print(f"Running PRISM: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            check=True,
            capture_output=False,  # Show output in console
        )
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        print(f"PRISM pipeline failed with exit code {e.returncode}", file=sys.stderr)
        return False
    except Exception as e:
        print(f"Error running PRISM: {e}", file=sys.stderr)
        return False


def launch_viewer(output_dir: Path) -> None:
    """Launch the PRISM viewer to display results."""
    import subprocess

    cmd = [
        sys.executable,
        "-m",
        "skyline_prism.gui.viewer",
        str(output_dir),
    ]

    print(f"Launching viewer: {' '.join(cmd)}")

    # Launch viewer as a detached process
    try:
        subprocess.Popen(
            cmd,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        print(f"Error launching viewer: {e}", file=sys.stderr)
        # Fall back to opening the HTML report
        html_report = output_dir / "qc_report.html"
        if html_report.exists():
            import webbrowser

            webbrowser.open(str(html_report))


def main() -> int:
    """Run the Skyline External Tool main entry point."""
    # Ensure dependencies are installed first
    if not ensure_dependencies():
        print("Failed to ensure dependencies. Exiting.", file=sys.stderr)
        return 1

    args = parse_args()

    # Validate input files exist
    if not args.report.exists():
        print(f"Error: Report file not found: {args.report}", file=sys.stderr)
        return 1

    if not args.metadata.exists():
        print(f"Error: Metadata file not found: {args.metadata}", file=sys.stderr)
        return 1

    print("PRISM External Tool")
    print(f"  Report: {args.report}")
    print(f"  Metadata: {args.metadata}")
    print(f"  Output: {args.output}")

    # Show configuration dialog
    config = show_config_dialog(args.metadata)

    if config is None:
        print("Configuration cancelled by user")
        return 0

    # Run the PRISM pipeline
    success = run_prism_pipeline(
        args.report,
        args.metadata,
        args.output,
        config,
    )

    if not success:
        return 1

    # Launch the viewer
    launch_viewer(args.output)

    return 0


if __name__ == "__main__":
    sys.exit(main())
