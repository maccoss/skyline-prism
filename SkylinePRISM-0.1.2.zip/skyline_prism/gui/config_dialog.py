"""PRISM Configuration Dialog for Skyline External Tool.

Provides a PyQt6-based dialog for configuring PRISM pipeline parameters
before running the analysis.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)


class PRISMConfigDialog(QDialog):
    """Configuration dialog for PRISM pipeline parameters.

    This dialog is shown before running the PRISM pipeline to allow users
    to configure key processing parameters.
    """

    def __init__(
        self,
        has_batch_column: bool = True,
        parent: QWidget | None = None,
    ) -> None:
        """Initialize the configuration dialog.

        Args:
            has_batch_column: Whether the metadata contains a batch column.
            parent: Parent widget.

        """
        super().__init__(parent)
        self.has_batch_column = has_batch_column
        self._setup_ui()
        self._load_settings()

    def _setup_ui(self) -> None:
        """Set up the dialog UI."""
        self.setWindowTitle("PRISM Configuration")
        self.setMinimumWidth(500)

        layout = QVBoxLayout(self)

        # Transition Rollup section
        layout.addWidget(self._create_transition_rollup_group())

        # Peptide Normalization section
        layout.addWidget(self._create_peptide_normalization_group())

        # Protein Inference section
        layout.addWidget(self._create_protein_inference_group())

        # Protein Rollup section
        layout.addWidget(self._create_protein_rollup_group())

        # Protein Normalization section
        layout.addWidget(self._create_protein_normalization_group())

        # Dialog buttons
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self._on_accept)
        button_box.rejected.connect(self.reject)

        # Rename OK button to "Run PRISM"
        ok_button = button_box.button(QDialogButtonBox.StandardButton.Ok)
        if ok_button:
            ok_button.setText("Run PRISM")

        layout.addWidget(button_box)

    def _create_transition_rollup_group(self) -> QGroupBox:
        """Create the Transition Rollup configuration group."""
        group = QGroupBox("Transition Rollup")
        layout = QFormLayout(group)

        # Method dropdown
        self.transition_method = QComboBox()
        self.transition_method.addItems(["adaptive", "median_polish", "sum", "topn"])
        self.transition_method.setCurrentText("adaptive")
        self.transition_method.currentTextChanged.connect(self._on_transition_method_changed)
        layout.addRow("Method:", self.transition_method)

        # Min transitions
        self.min_transitions = QSpinBox()
        self.min_transitions.setRange(1, 10)
        self.min_transitions.setValue(3)
        layout.addRow("Min Transitions:", self.min_transitions)

        # Learn weights checkbox (only for adaptive)
        self.learn_weights = QCheckBox("Learn weights from reference samples")
        self.learn_weights.setChecked(True)
        layout.addRow("", self.learn_weights)

        return group

    def _create_peptide_normalization_group(self) -> QGroupBox:
        """Create the Peptide Normalization configuration group."""
        group = QGroupBox("Peptide Normalization")
        layout = QFormLayout(group)

        # Method dropdown
        self.peptide_norm_method = QComboBox()
        self.peptide_norm_method.addItems(["rt_lowess", "median", "none"])
        self.peptide_norm_method.setCurrentText("rt_lowess")
        layout.addRow("Method:", self.peptide_norm_method)

        # Batch correction checkbox
        self.peptide_batch_correction = QCheckBox("Batch Correction")
        self.peptide_batch_correction.setChecked(self.has_batch_column)
        if not self.has_batch_column:
            self.peptide_batch_correction.setEnabled(False)
            self.peptide_batch_correction.setToolTip(
                "Disabled: No 'Batch' column found in metadata"
            )
        layout.addRow("", self.peptide_batch_correction)

        return group

    def _create_protein_inference_group(self) -> QGroupBox:
        """Create the Protein Inference configuration group."""
        group = QGroupBox("Protein Inference")
        layout = QFormLayout(group)

        # FASTA file picker
        fasta_layout = QHBoxLayout()
        self.fasta_path = QLineEdit()
        self.fasta_path.setPlaceholderText("(Optional) Select FASTA file...")
        fasta_layout.addWidget(self.fasta_path)

        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self._browse_fasta)
        fasta_layout.addWidget(browse_btn)

        layout.addRow("FASTA File:", fasta_layout)

        # Shared peptide handling
        self.shared_peptides = QComboBox()
        self.shared_peptides.addItems(["all_groups", "unique_only", "razor"])
        self.shared_peptides.setCurrentText("all_groups")
        layout.addRow("Shared Peptides:", self.shared_peptides)

        return group

    def _create_protein_rollup_group(self) -> QGroupBox:
        """Create the Protein Rollup configuration group."""
        group = QGroupBox("Protein Rollup")
        layout = QFormLayout(group)

        # Method dropdown
        self.protein_rollup_method = QComboBox()
        self.protein_rollup_method.addItems(
            [
                "median_polish",
                "sum",
                "topn",
                "ibaq (experimental)",
                "maxlfq (experimental)",
            ]
        )
        self.protein_rollup_method.setCurrentText("median_polish")
        layout.addRow("Method:", self.protein_rollup_method)

        # Min peptides
        self.min_peptides = QSpinBox()
        self.min_peptides.setRange(1, 10)
        self.min_peptides.setValue(2)
        layout.addRow("Min Peptides:", self.min_peptides)

        return group

    def _create_protein_normalization_group(self) -> QGroupBox:
        """Create the Protein Normalization configuration group."""
        group = QGroupBox("Protein Normalization")
        layout = QFormLayout(group)

        # Method dropdown
        self.protein_norm_method = QComboBox()
        self.protein_norm_method.addItems(["median", "none"])
        self.protein_norm_method.setCurrentText("median")
        layout.addRow("Method:", self.protein_norm_method)

        # Batch correction checkbox
        self.protein_batch_correction = QCheckBox("Batch Correction")
        self.protein_batch_correction.setChecked(self.has_batch_column)
        if not self.has_batch_column:
            self.protein_batch_correction.setEnabled(False)
            self.protein_batch_correction.setToolTip(
                "Disabled: No 'Batch' column found in metadata"
            )
        layout.addRow("", self.protein_batch_correction)

        return group

    def _on_transition_method_changed(self, method: str) -> None:
        """Handle transition method change."""
        # Learn weights only applicable for adaptive
        self.learn_weights.setEnabled(method == "adaptive")
        if method != "adaptive":
            self.learn_weights.setChecked(False)

    def _browse_fasta(self) -> None:
        """Open file dialog to select FASTA file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select FASTA File",
            "",
            "FASTA Files (*.fasta *.fa *.faa);;All Files (*)",
        )
        if file_path:
            self.fasta_path.setText(file_path)

    def _on_accept(self) -> None:
        """Handle dialog acceptance."""
        # Validate FASTA requirement for ibaq/maxlfq
        method = self.protein_rollup_method.currentText()
        if "ibaq" in method or "maxlfq" in method:
            if not self.fasta_path.text():
                from PyQt6.QtWidgets import QMessageBox

                QMessageBox.warning(
                    self,
                    "FASTA Required",
                    f"The {method.split()[0]} method requires a FASTA file.\n"
                    "Please select a FASTA file or choose a different method.",
                )
                return

        self._save_settings()
        self.accept()

    def get_config(self) -> dict[str, Any]:
        """Get the configuration dictionary from dialog values.

        Returns:
            Dictionary containing PRISM configuration settings.

        """
        # Parse protein rollup method (remove experimental tag)
        protein_method = self.protein_rollup_method.currentText()
        if "(" in protein_method:
            protein_method = protein_method.split()[0]

        config: dict[str, Any] = {
            "transition_rollup": {
                "enabled": True,
                "method": self.transition_method.currentText(),
                "min_transitions": self.min_transitions.value(),
                "learn_adaptive_weights": self.learn_weights.isChecked(),
            },
            "global_normalization": {
                "method": self.peptide_norm_method.currentText(),
            },
            "peptide_batch_correction": {
                "enabled": self.peptide_batch_correction.isChecked() and self.has_batch_column,
            },
            "protein_rollup": {
                "method": protein_method,
                "min_peptides": self.min_peptides.value(),
            },
            "protein_normalization": {
                "method": self.protein_norm_method.currentText(),
            },
            "protein_batch_correction": {
                "enabled": self.protein_batch_correction.isChecked() and self.has_batch_column,
            },
        }

        # Add parsimony if FASTA provided
        fasta_path = self.fasta_path.text()
        if fasta_path:
            config["parsimony"] = {
                "enabled": True,
                "fasta_path": fasta_path,
                "shared_peptide_handling": self.shared_peptides.currentText(),
            }
        else:
            config["parsimony"] = {
                "enabled": False,
            }

        return config

    def _get_settings_path(self) -> Path:
        """Get the path to the settings file."""
        # Store settings in user's config directory
        config_dir = Path.home() / ".config" / "skyline-prism"
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir / "dialog_settings.json"

    def _save_settings(self) -> None:
        """Save current settings for next use."""
        settings = {
            "transition_method": self.transition_method.currentText(),
            "min_transitions": self.min_transitions.value(),
            "learn_weights": self.learn_weights.isChecked(),
            "peptide_norm_method": self.peptide_norm_method.currentText(),
            "peptide_batch_correction": self.peptide_batch_correction.isChecked(),
            "fasta_path": self.fasta_path.text(),
            "shared_peptides": self.shared_peptides.currentText(),
            "protein_rollup_method": self.protein_rollup_method.currentText(),
            "min_peptides": self.min_peptides.value(),
            "protein_norm_method": self.protein_norm_method.currentText(),
            "protein_batch_correction": self.protein_batch_correction.isChecked(),
        }

        try:
            with open(self._get_settings_path(), "w") as f:
                json.dump(settings, f, indent=2)
        except Exception:
            pass  # Silently fail if we can't save settings

    def _load_settings(self) -> None:
        """Load previously saved settings."""
        settings_path = self._get_settings_path()
        if not settings_path.exists():
            return

        try:
            with open(settings_path) as f:
                settings = json.load(f)

            # Apply settings to widgets
            if "transition_method" in settings:
                self.transition_method.setCurrentText(settings["transition_method"])
            if "min_transitions" in settings:
                self.min_transitions.setValue(settings["min_transitions"])
            if "learn_weights" in settings:
                self.learn_weights.setChecked(settings["learn_weights"])
            if "peptide_norm_method" in settings:
                self.peptide_norm_method.setCurrentText(settings["peptide_norm_method"])
            if "peptide_batch_correction" in settings and self.has_batch_column:
                self.peptide_batch_correction.setChecked(settings["peptide_batch_correction"])
            if "fasta_path" in settings:
                self.fasta_path.setText(settings["fasta_path"])
            if "shared_peptides" in settings:
                self.shared_peptides.setCurrentText(settings["shared_peptides"])
            if "protein_rollup_method" in settings:
                self.protein_rollup_method.setCurrentText(settings["protein_rollup_method"])
            if "min_peptides" in settings:
                self.min_peptides.setValue(settings["min_peptides"])
            if "protein_norm_method" in settings:
                self.protein_norm_method.setCurrentText(settings["protein_norm_method"])
            if "protein_batch_correction" in settings and self.has_batch_column:
                self.protein_batch_correction.setChecked(settings["protein_batch_correction"])
        except Exception:
            pass  # Silently fail if we can't load settings


if __name__ == "__main__":
    # Test the dialog
    import pprint
    import sys

    from PyQt6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    dialog = PRISMConfigDialog(has_batch_column=True)

    if dialog.exec():
        print("Configuration:")
        pprint.pprint(dialog.get_config())
    else:
        print("Cancelled")

    sys.exit(0)
